// #include<stdio.h>
// int calPer( float a,float b,float c){
//     float total = (a+b+c);
//     float percentage =( total/300.0)*100.0;
//     return percentage;
// }

// int main(){
//     float a,b,c,percentage;
//     printf("enter science marks: ");
//     scanf("%f",&a);
//     printf("enter sst marks: ");
//     scanf("%f",&b);
//     printf("enter sanskrit marks: ");
//     scanf("%f",&c);
//     int ans = calPer(a,b,c);
//     printf("percentage of all subjects:%f",ans);
// }
#include<stdio.h>
int calcPer(float a,float b,float c,float percentage);
int main(){
    float a,b,c,percentage;
     printf("enter science marks: ");
  scanf("%f",&a);
   printf("enter sst marks: ");
     scanf("%f",&b);
    printf("enter sanskrit marks: ");
   scanf("%f",&c);
   float percentage=calPer(a,b,c);
}
int calcPer(float a,float b,float c,float percentage){
   float percentage=((a+b+c)/300)*100;
    return percentage;
}